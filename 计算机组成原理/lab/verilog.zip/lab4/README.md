cpu_one 为文件
single 为测试目录
但 coe 文件我扔在 single 里面了
